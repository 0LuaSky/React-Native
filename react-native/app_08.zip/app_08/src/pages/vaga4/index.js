import {View, Text, Image, ScrollView} from 'react-native';
import {styles } from './style.js';
import {useState} from 'react'


function App(){
  let foto = 'https://img.olx.com.br/images/56/564442342617916.jpg';

  const [num1, setnum1] = useState('')

  function entrar(){
    setnum1(Math.floor(Math.random() * 11));
  }

  
  return(
    <View style={styles.main}>

        <Text style={styles.titulo} >
          Desenvolvedor de jogos
        </Text>

        <Text style={styles.texto} >
          Salario: R$ 3.266
        </Text>
        <Text style={styles.texto} >
          Descrição: ___________ ______________ _____ __________ ____________ 
        </Text> 
        <Text style={styles.texto} >
          Contato: ** *****-****
        </Text>


    </View>
  )
};

export default App;