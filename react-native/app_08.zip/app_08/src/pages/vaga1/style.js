import { StyleSheet } from 'react-native'

const styles = StyleSheet.create({
  main:{
    margin:20,
    height:400,
    borderWidth: 2,
    borderColor: 'white',
    borderRadius: 10,
  },

  titulo:{
    margin:10,
    color: 'white',
    textAlign: 'center',
    fontSize: 35,
  },

  texto:{
    margin:10,
    color: 'white',
    marginBottom: 20,
    fontSize: 25,

  },

  
  resposta:{
    alignSelf: 'center',
    width: 150,
    borderBottomWidth:3,
    borderColor:'white',
    color: 'white',
    marginBottom: 30,
    textAlign: 'center',
    fontSize: 30,

  },
});


export {styles}