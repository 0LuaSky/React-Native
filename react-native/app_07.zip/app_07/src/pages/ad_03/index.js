import {View, Text, Image, ScrollView} from 'react-native';
import {styles } from './style.js';
import {useState} from 'react'


function App(){
  let foto = 'https://c4.wallpaperflare.com/wallpaper/318/373/100/aunt-cass-big-hero-6-hd-wallpaper-preview.jpg';

  const [num1, setnum1] = useState('')

  function entrar(){
    setnum1(Math.floor(Math.random() * 11));
  }

  
  return(
    <View style={styles.main}>
      <ScrollView>
        <Text style={styles.titulo} >
          Tias solteiras na area
        </Text>

        <Image style={styles.imagens} source={{uri:foto}}/>

        <Text style={styles.texto} >
         Tias desesperadas por compania na sua area.
        </Text>

      </ScrollView>
    </View>
  )
};

export default App;