import {View, Text, Image, ScrollView} from 'react-native';
import {styles } from './style.js';
import {useState} from 'react'


function App(){
  let foto = 'https://www.alura.com.br/assets/img/alura-share.1730889067.png';

  const [num1, setnum1] = useState('')

  function entrar(){
    setnum1(Math.floor(Math.random() * 11));
  }

  
  return(
    <View style={styles.main}>
      <ScrollView>
        <Text style={styles.titulo} >
          Cursos com ate 50% off
        </Text>

        <Image style={styles.imagens} source={{uri:foto}}/>

        <Text style={styles.texto} >
         Transforme sua carreira com o maior desconto do ano.
        </Text>
        <Text style={styles.texto} >
         A oportunidade que você estava esperando para impulsionar a sua carreira tech. Só até dia 29 de novembro.
        </Text>

      </ScrollView>
    </View>
  )
};

export default App;