import {View, Text, Image, ScrollView} from 'react-native';
import {styles } from './style.js';
import {useState} from 'react'


function App(){
  let foto = 'https://img.olx.com.br/images/56/564442342617916.jpg';

  const [num1, setnum1] = useState('')

  function entrar(){
    setnum1(Math.floor(Math.random() * 11));
  }

  
  return(
    <View style={styles.main}>
      <ScrollView>
        <Text style={styles.titulo} >
          Monza RARIDADE, interior impecável, lataria impecável, novo, veículo para COLECIONADOR!
        </Text>

        <Image style={styles.imagens} source={{uri:foto}}/>

        <Text style={styles.texto} >
         R$
29.900
        </Text>

      </ScrollView>
    </View>
  )
};

export default App;