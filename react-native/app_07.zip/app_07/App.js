import {Text, View, StyleSheet, ScrollView } from 'react-native';
import AD1 from './src/pages/ad_01/index';
import AD2 from './src/pages/ad_02/index';
import AD3 from './src/pages/ad_03/index';


function App(){
  return(
    <View style={styles.background}>
      <ScrollView style={styles.main}>  
        <Text style={styles.titulo}> Anuncios </Text>
        
        <View style={styles.content}>
          <ScrollView horizontal={true} showsHorizontalScrollIndicator={false}>
            <AD1 style={styles.content}/>
            <AD2 style={styles.content}/>
            <AD3 style={styles.content}/>
            
          </ScrollView>
        </View>
        
        <Text style={styles.texto}> Texto brabo aqui viado</Text>
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
  background:{
    flex: 1,
    backgroundColor: 'black',
  },
  
  main:{
    margin: 10,

  },

  titulo:{
    color: 'white',
    marginBottom: 20,
    textAlign: 'center',
    fontSize: 80,
  },

  content:{ 
    height:450,
    borderWidth: 2,
    borderColor: 'white',
    borderRadius: 10,
  },

  texto:{
    marginTop:30,
    color: 'white',
    marginBottom: 20,
    textAlign: 'center',
    fontSize: 40,
  }
});

export default App;

